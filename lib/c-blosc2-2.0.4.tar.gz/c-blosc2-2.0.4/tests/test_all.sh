#*********************************************************************
#  Blosc - Blocked Shuffling and Compression Library
#
#  Unit tests for basic features in Blosc.
#
#  Author: The Blosc Developers <blosc@blosc.org>
#
#  See LICENSE.txt for details about copyright and rights to use.
#**********************************************************************

for exe in $(ls *.exe); do
    ./$exe
done
