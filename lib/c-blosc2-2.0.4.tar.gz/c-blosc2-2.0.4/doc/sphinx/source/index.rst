.. Blosc2 documentation master file, created by
   sphinx-quickstart on Fri Apr 30 08:24:27 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


.. include:: ../../../README.rst

.. toctree::
   :hidden:

   API Reference <reference/index>
   Format <format/index>
   Development <development/index>
