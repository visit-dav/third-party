.. include:: ../../../THANKS.rst
